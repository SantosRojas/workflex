<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Dashboard')); ?> - <?php echo e(Carbon\Carbon::create($currentYear, $currentMonth, 1)->locale('es')->monthName); ?>

            <?php echo e($currentYear); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            
            <?php if (isset($component)) { $__componentOriginal5d959b87a2da7a329af8807b4ec34660 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5d959b87a2da7a329af8807b4ec34660 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.welcome-card','data' => ['user' => $user,'planningPeriod' => $planningPeriod]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.welcome-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user),'planningPeriod' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($planningPeriod)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5d959b87a2da7a329af8807b4ec34660)): ?>
<?php $attributes = $__attributesOriginal5d959b87a2da7a329af8807b4ec34660; ?>
<?php unset($__attributesOriginal5d959b87a2da7a329af8807b4ec34660); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5d959b87a2da7a329af8807b4ec34660)): ?>
<?php $component = $__componentOriginal5d959b87a2da7a329af8807b4ec34660; ?>
<?php unset($__componentOriginal5d959b87a2da7a329af8807b4ec34660); ?>
<?php endif; ?>

            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                <?php if (isset($component)) { $__componentOriginal457ade557f73eaa008f851091260abe1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal457ade557f73eaa008f851091260abe1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.stat-card','data' => ['icon' => 'home','iconBg' => 'blue','label' => 'Mis días Home Office','value' => $myHomeOfficeDays . ' / ' . $maxHomeOfficeDays]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'home','iconBg' => 'blue','label' => 'Mis días Home Office','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($myHomeOfficeDays . ' / ' . $maxHomeOfficeDays)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal457ade557f73eaa008f851091260abe1)): ?>
<?php $attributes = $__attributesOriginal457ade557f73eaa008f851091260abe1; ?>
<?php unset($__attributesOriginal457ade557f73eaa008f851091260abe1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal457ade557f73eaa008f851091260abe1)): ?>
<?php $component = $__componentOriginal457ade557f73eaa008f851091260abe1; ?>
<?php unset($__componentOriginal457ade557f73eaa008f851091260abe1); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal457ade557f73eaa008f851091260abe1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal457ade557f73eaa008f851091260abe1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.stat-card','data' => ['icon' => 'clock','iconBg' => 'green','label' => 'Mi horario','value' => $myFlexibleSchedule ? substr($myFlexibleSchedule->start_time, 0, 5) : '08:00']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'clock','iconBg' => 'green','label' => 'Mi horario','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($myFlexibleSchedule ? substr($myFlexibleSchedule->start_time, 0, 5) : '08:00')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal457ade557f73eaa008f851091260abe1)): ?>
<?php $attributes = $__attributesOriginal457ade557f73eaa008f851091260abe1; ?>
<?php unset($__attributesOriginal457ade557f73eaa008f851091260abe1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal457ade557f73eaa008f851091260abe1)): ?>
<?php $component = $__componentOriginal457ade557f73eaa008f851091260abe1; ?>
<?php unset($__componentOriginal457ade557f73eaa008f851091260abe1); ?>
<?php endif; ?>

                <?php if($user->canManageAssignments()): ?>
                    <?php if (isset($component)) { $__componentOriginal457ade557f73eaa008f851091260abe1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal457ade557f73eaa008f851091260abe1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.stat-card','data' => ['icon' => 'users','iconBg' => 'purple','label' => 'Home Office hoy','value' => $teamHomeOfficeToday->count()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'users','iconBg' => 'purple','label' => 'Home Office hoy','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($teamHomeOfficeToday->count())]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal457ade557f73eaa008f851091260abe1)): ?>
<?php $attributes = $__attributesOriginal457ade557f73eaa008f851091260abe1; ?>
<?php unset($__attributesOriginal457ade557f73eaa008f851091260abe1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal457ade557f73eaa008f851091260abe1)): ?>
<?php $component = $__componentOriginal457ade557f73eaa008f851091260abe1; ?>
<?php unset($__componentOriginal457ade557f73eaa008f851091260abe1); ?>
<?php endif; ?>

                    <?php if (isset($component)) { $__componentOriginal457ade557f73eaa008f851091260abe1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal457ade557f73eaa008f851091260abe1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.stat-card','data' => ['icon' => 'clipboard','iconBg' => 'orange','label' => 'Horarios flexibles','value' => $teamFlexibleCount]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'clipboard','iconBg' => 'orange','label' => 'Horarios flexibles','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($teamFlexibleCount)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal457ade557f73eaa008f851091260abe1)): ?>
<?php $attributes = $__attributesOriginal457ade557f73eaa008f851091260abe1; ?>
<?php unset($__attributesOriginal457ade557f73eaa008f851091260abe1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal457ade557f73eaa008f851091260abe1)): ?>
<?php $component = $__componentOriginal457ade557f73eaa008f851091260abe1; ?>
<?php unset($__componentOriginal457ade557f73eaa008f851091260abe1); ?>
<?php endif; ?>
                <?php else: ?>
                    
                    <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg p-4 col-span-2">
                        <div class="flex items-center">
                            <div class="p-3 rounded-full bg-purple-100 dark:bg-purple-800 mr-3">
                                <svg class="w-5 h-5 text-purple-600 dark:text-purple-300" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z">
                                    </path>
                                </svg>
                            </div>
                            <div>
                                <p class="text-xs text-gray-500 dark:text-gray-400">Próximo Home Office</p>
                                <p class="text-lg font-bold text-gray-900 dark:text-gray-100">
                                    <?php if($nextHomeOffice): ?>
                                        <?php echo e($nextHomeOffice->date->locale('es')->isoFormat('dddd D [de] MMMM')); ?>

                                    <?php else: ?>
                                        Sin asignar
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            
            <?php if (isset($component)) { $__componentOriginala2216a5186ae8b8d7fdb7519ba381c09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala2216a5186ae8b8d7fdb7519ba381c09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.home-office-calendar','data' => ['user' => $user,'currentYear' => $currentYear,'currentMonth' => $currentMonth,'homeOfficeAssignments' => $homeOfficeAssignments]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.home-office-calendar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user),'currentYear' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($currentYear),'currentMonth' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($currentMonth),'homeOfficeAssignments' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($homeOfficeAssignments)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala2216a5186ae8b8d7fdb7519ba381c09)): ?>
<?php $attributes = $__attributesOriginala2216a5186ae8b8d7fdb7519ba381c09; ?>
<?php unset($__attributesOriginala2216a5186ae8b8d7fdb7519ba381c09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala2216a5186ae8b8d7fdb7519ba381c09)): ?>
<?php $component = $__componentOriginala2216a5186ae8b8d7fdb7519ba381c09; ?>
<?php unset($__componentOriginala2216a5186ae8b8d7fdb7519ba381c09); ?>
<?php endif; ?>

            
            <?php if($user->canManageAssignments()): ?>
                <?php if (isset($component)) { $__componentOriginal70ebe1dadbb42df9c29fd6a89778eaac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70ebe1dadbb42df9c29fd6a89778eaac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.flexible-schedule-grid','data' => ['currentYear' => $currentYear,'currentMonth' => $currentMonth,'flexibleAssignments' => $flexibleAssignments]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.flexible-schedule-grid'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['currentYear' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($currentYear),'currentMonth' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($currentMonth),'flexibleAssignments' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($flexibleAssignments)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70ebe1dadbb42df9c29fd6a89778eaac)): ?>
<?php $attributes = $__attributesOriginal70ebe1dadbb42df9c29fd6a89778eaac; ?>
<?php unset($__attributesOriginal70ebe1dadbb42df9c29fd6a89778eaac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70ebe1dadbb42df9c29fd6a89778eaac)): ?>
<?php $component = $__componentOriginal70ebe1dadbb42df9c29fd6a89778eaac; ?>
<?php unset($__componentOriginal70ebe1dadbb42df9c29fd6a89778eaac); ?>
<?php endif; ?>
            <?php endif; ?>

        </div>
    </div>

    
    <?php if (isset($component)) { $__componentOriginal03bbbf13e35a64b803751e4e27c41bec = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal03bbbf13e35a64b803751e4e27c41bec = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.modal','data' => ['id' => 'dayModal','titleId' => 'modalTitle','contentId' => 'modalContent','closeFunction' => 'closeDayModal','linkId' => 'modalLink','linkText' => 'Ver todas las asignaciones →','linkColor' => 'blue']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'dayModal','titleId' => 'modalTitle','contentId' => 'modalContent','closeFunction' => 'closeDayModal','linkId' => 'modalLink','linkText' => 'Ver todas las asignaciones →','linkColor' => 'blue']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal03bbbf13e35a64b803751e4e27c41bec)): ?>
<?php $attributes = $__attributesOriginal03bbbf13e35a64b803751e4e27c41bec; ?>
<?php unset($__attributesOriginal03bbbf13e35a64b803751e4e27c41bec); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal03bbbf13e35a64b803751e4e27c41bec)): ?>
<?php $component = $__componentOriginal03bbbf13e35a64b803751e4e27c41bec; ?>
<?php unset($__componentOriginal03bbbf13e35a64b803751e4e27c41bec); ?>
<?php endif; ?>

    
    <?php if (isset($component)) { $__componentOriginal03bbbf13e35a64b803751e4e27c41bec = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal03bbbf13e35a64b803751e4e27c41bec = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.modal','data' => ['id' => 'flexibleModal','titleId' => 'flexibleModalTitle','contentId' => 'flexibleModalContent','closeFunction' => 'closeFlexibleModal','linkHref' => route('flexible-schedule.index'),'linkText' => 'Gestionar horarios flexibles →','linkColor' => 'green']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'flexibleModal','titleId' => 'flexibleModalTitle','contentId' => 'flexibleModalContent','closeFunction' => 'closeFlexibleModal','linkHref' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('flexible-schedule.index')),'linkText' => 'Gestionar horarios flexibles →','linkColor' => 'green']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal03bbbf13e35a64b803751e4e27c41bec)): ?>
<?php $attributes = $__attributesOriginal03bbbf13e35a64b803751e4e27c41bec; ?>
<?php unset($__attributesOriginal03bbbf13e35a64b803751e4e27c41bec); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal03bbbf13e35a64b803751e4e27c41bec)): ?>
<?php $component = $__componentOriginal03bbbf13e35a64b803751e4e27c41bec; ?>
<?php unset($__componentOriginal03bbbf13e35a64b803751e4e27c41bec); ?>
<?php endif; ?>

    
    <?php if (isset($component)) { $__componentOriginalb922593c96bfbd5b0342134422822968 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb922593c96bfbd5b0342134422822968 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.scripts','data' => ['homeOfficeByDate' => $homeOfficeByDate,'flexibleByArea' => $flexibleByArea]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['homeOfficeByDate' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($homeOfficeByDate),'flexibleByArea' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($flexibleByArea)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb922593c96bfbd5b0342134422822968)): ?>
<?php $attributes = $__attributesOriginalb922593c96bfbd5b0342134422822968; ?>
<?php unset($__attributesOriginalb922593c96bfbd5b0342134422822968); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb922593c96bfbd5b0342134422822968)): ?>
<?php $component = $__componentOriginalb922593c96bfbd5b0342134422822968; ?>
<?php unset($__componentOriginalb922593c96bfbd5b0342134422822968); ?>
<?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\PROJECTS\Laravel\workflex\resources\views/dashboard.blade.php ENDPATH**/ ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['user', 'planningPeriod']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['user', 'planningPeriod']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg mb-6">
    <div class="p-6 text-gray-900 dark:text-gray-100">
        <div class="flex justify-between items-center">
            <div>
                <h3 class="text-lg font-semibold mb-2">¡Bienvenido, <?php echo e($user->name); ?>!</h3>
                <p class="text-gray-600 dark:text-gray-400">
                    <span class="font-medium">Área:</span> <?php echo e($user->work_area); ?> 
                    
                </p>
            </div>
            <div class="text-right">
                <span
                    class="inline-flex items-center px-3 py-1 rounded-full text-sm <?php echo e($planningPeriod['isActive'] ? 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100' : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100'); ?>">
                    <?php echo e($planningPeriod['isActive'] ? '✅ Período de planificación activo' : '⏰ Fuera de período'); ?>

                </span>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\PROJECTS\Laravel\workflex\resources\views/components/dashboard/welcome-card.blade.php ENDPATH**/ ?>
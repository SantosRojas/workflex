<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['user', 'currentYear', 'currentMonth', 'homeOfficeAssignments']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['user', 'currentYear', 'currentMonth', 'homeOfficeAssignments']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $firstDay = Carbon\Carbon::create($currentYear, $currentMonth, 1);
    $lastDay = $firstDay->copy()->endOfMonth();
    $startPadding = $firstDay->dayOfWeekIso - 1;
    $assignmentsByDate = $homeOfficeAssignments->groupBy(fn($a) => $a->date->format('Y-m-d'));

    // Calcular mes anterior y siguiente
    $previousMonth = $firstDay->copy()->subMonth();
    $nextMonth = $firstDay->copy()->addMonth();
?>

<div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg mb-6">
    <div class="p-6">
        
        <div class="flex justify-between items-center mb-4">
            <div class="flex items-center gap-2">
                
                <?php if($user->canManageAssignments()): ?>
                    <a href="<?php echo e(route('dashboard', ['month' => $previousMonth->month, 'year' => $previousMonth->year])); ?>"
                        class="inline-flex items-center justify-center w-8 h-8 rounded-md bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
                        title="Mes anterior">
                        ←
                    </a>
                <?php endif; ?>

                <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-200 min-w-max">
                    📅 Calendario -
                    <?php echo e(Carbon\Carbon::create($currentYear, $currentMonth, 1)->locale('es')->monthName); ?>

                    <?php echo e($currentYear); ?>

                </h3>

                
                <?php if($user->canManageAssignments()): ?>
                    <a href="<?php echo e(route('dashboard', ['month' => $nextMonth->month, 'year' => $nextMonth->year])); ?>"
                        class="inline-flex items-center justify-center w-8 h-8 rounded-md bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
                        title="Mes siguiente">
                        →
                    </a>
                <?php endif; ?>
            </div>

            <?php if($user->canManageAssignments()): ?>
                <a href="<?php echo e(route('home-office.index')); ?>"
                    class="text-sm text-blue-600 hover:text-blue-800 dark:text-blue-400">
                    Gestionar asignaciones →
                </a>
            <?php endif; ?>
        </div>

        
        <div class="flex flex-wrap gap-4 mb-4 text-sm">
            <div class="flex items-center">
                <span class="w-3 h-3 bg-blue-500 rounded-full mr-2"></span>
                <span class="text-gray-600 dark:text-gray-400">Tiene asignaciones</span>
            </div>
            <div class="flex items-center">
                <span class="w-3 h-3 bg-green-500 rounded-full mr-2"></span>
                <span class="text-gray-600 dark:text-gray-400">Hoy</span>
            </div>
            <div class="flex items-center">
                <span class="w-3 h-3 bg-gray-300 dark:bg-gray-600 rounded-full mr-2"></span>
                <span class="text-gray-600 dark:text-gray-400">Fin de semana</span>
            </div>
        </div>

        
        <div class="grid grid-cols-7 gap-2 mb-2">
            <?php $__currentLoopData = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dayName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div
                    class="text-center text-sm font-semibold text-gray-600 dark:text-gray-400 py-2 <?php echo e(in_array($dayName, ['Sáb', 'Dom']) ? 'text-gray-400' : ''); ?>">
                    <?php echo e($dayName); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <div class="grid grid-cols-7 gap-2">
            
            <?php for($i = 0; $i < $startPadding; $i++): ?>
                <div class="h-20 bg-gray-50 dark:bg-gray-900 rounded-lg"></div>
            <?php endfor; ?>

            
            <?php for($day = 1; $day <= $lastDay->day; $day++): ?>
                <?php
                    $currentDate = Carbon\Carbon::create($currentYear, $currentMonth, $day);
                    $dateKey = $currentDate->format('Y-m-d');
                    $isWeekend = $currentDate->isWeekend();
                    $isToday = $currentDate->isToday();
                    $dayAssignments = $assignmentsByDate->get($dateKey, collect());
                    $hasAssignments = $dayAssignments->count() > 0;
                ?>
                <div <?php if($hasAssignments && !$isWeekend): ?>
                    onclick="openDayModal('<?php echo e($dateKey); ?>', '<?php echo e($currentDate->locale('es')->isoFormat('dddd D [de] MMMM')); ?>')"
                <?php endif; ?> class="h-20 p-2 rounded-lg border-2 transition-all overflow-hidden
                                <?php echo e($isWeekend ? 'bg-gray-100 dark:bg-gray-900 border-gray-200 dark:border-gray-700 opacity-60' : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700'); ?>

                                <?php echo e($isToday ? 'ring-2 ring-green-500 ring-offset-2 dark:ring-offset-gray-800' : ''); ?>

                                <?php echo e($hasAssignments && !$isWeekend ? 'cursor-pointer hover:bg-blue-50 dark:hover:bg-blue-900/50 hover:border-blue-400 dark:hover:border-blue-500' : ''); ?>

                            ">
                    <div class="flex justify-between items-start">
                        <span
                            class="text-sm font-bold <?php echo e($isToday ? 'text-green-600 dark:text-green-400' : ($isWeekend ? 'text-gray-400 dark:text-gray-500' : 'text-gray-700 dark:text-gray-300')); ?>">
                            <?php echo e($day); ?>

                        </span>
                        <?php if($hasAssignments && !$isWeekend): ?>
                            <span
                                class="flex items-center justify-center w-5 h-5 text-xs font-bold text-white bg-blue-500 rounded-full shadow-sm">
                                <?php echo e($dayAssignments->count()); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                    <?php if($hasAssignments && !$isWeekend): ?>
                        <div class="mt-1 space-y-0.5">
                            <?php $__currentLoopData = $dayAssignments->take(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="text-xs text-blue-600 dark:text-blue-400 truncate leading-tight">
                                    <?php echo e(Str::before($assignment->user->name, ' ')); ?>

                                </p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($dayAssignments->count() > 2): ?>
                                <p class="text-xs text-gray-500 dark:text-gray-400">+<?php echo e($dayAssignments->count() - 2); ?> más</p>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endfor; ?>
        </div>
    </div>
</div><?php /**PATH C:\PROJECTS\Laravel\workflex\resources\views/components/dashboard/home-office-calendar.blade.php ENDPATH**/ ?>
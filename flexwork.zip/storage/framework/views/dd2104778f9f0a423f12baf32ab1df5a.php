<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'id',
    'titleId',
    'contentId',
    'closeFunction',
    'linkHref' => '#',
    'linkText' => 'Ver más →',
    'linkId' => null,
    'linkColor' => 'blue'
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'id',
    'titleId',
    'contentId',
    'closeFunction',
    'linkHref' => '#',
    'linkText' => 'Ver más →',
    'linkId' => null,
    'linkColor' => 'blue'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $linkColors = [
        'blue' => 'text-blue-600 hover:text-blue-800 dark:text-blue-400',
        'green' => 'text-green-600 hover:text-green-800 dark:text-green-400',
    ];
?>

<div id="<?php echo e($id); ?>" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full z-50">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white dark:bg-gray-800">
        <div class="flex justify-between items-center mb-4">
            <h3 id="<?php echo e($titleId); ?>" class="text-lg font-medium text-gray-900 dark:text-gray-100"></h3>
            <button onclick="<?php echo e($closeFunction); ?>()" class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewB
               ox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
        </div>
        <div id="<?php echo e($contentId); ?>" class="space-y-3 max-h-80 overflow-y-auto">
            
        </div>
        <div class="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
            <a <?php if($linkId): ?> id="<?php echo e($linkId); ?>" <?php endif; ?> href="<?php echo e($linkHref); ?>" class="text-sm <?php echo e($linkColors[$linkColor] ?? $linkColors['blue']); ?>">
                <?php echo e($linkText); ?>

            </a>
        </div>
    </div>
</div>
<?php /**PATH C:\PROJECTS\Laravel\workflex\resources\views/components/dashboard/modal.blade.php ENDPATH**/ ?>
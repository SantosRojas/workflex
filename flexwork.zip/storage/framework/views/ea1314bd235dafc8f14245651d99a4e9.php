

<img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo" /><?php /**PATH C:\PROJECTS\Laravel\workflex\resources\views/components/application-logo.blade.php ENDPATH**/ ?>